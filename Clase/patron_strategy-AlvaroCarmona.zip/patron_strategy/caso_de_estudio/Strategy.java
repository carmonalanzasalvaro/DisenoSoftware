package Clase.patron_strategy.caso_de_estudio;

public interface Strategy extends Consulta{
    void examinar();
    void enviarFactura();
    void enviarResultado();
}
