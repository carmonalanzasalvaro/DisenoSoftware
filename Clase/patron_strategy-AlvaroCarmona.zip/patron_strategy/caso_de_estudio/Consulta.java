package Clase.patron_strategy.caso_de_estudio;
//interfaz que implementarán las clases concretas de cada estrategia, tiene como fin lograr una abstracción más en el contexto Guardería.
public interface Consulta {
    void realizarConsulta();
}
